import {Component,Input,Output,EventEmitter,OnInit} from '@angular/core';
import {BookService} from './app.bookservice';


@Component({
    selector:'add-comp',
    templateUrl:'addbook.html'
})
export class AddBookComponent implements OnInit{
    constructor(private service:BookService){}
    bookAll:any[]=[];
    ngOnInit(){
        this.service.getAllBook().subscribe((data:any)=>this.bookAll=data);
    }
   

}
   